import random
import time
import cProfile
import matplotlib.pyplot as plt


def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    return merge(left, right)


def merge(left, right):
    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result


if __name__ == "__main__":
    sizes = list(range(1000, 11000, 1000))
    times = []

    for size in sizes:
        random_array = [random.randint(1, 10000) for _ in range(size)]
        profiler = cProfile.Profile()
        profiler.enable()

        start_time = time.time()
        sorted_array = merge_sort(random_array)
        end_time = time.time()

        profiler.disable()
        profiler.print_stats(sort='cumulative')

        sorting_time = end_time - start_time
        times.append(sorting_time)
        print(
            f"Sorting array of size {size} took {sorting_time:.6f} seconds\n")

    # Plotting the data
    plt.plot(sizes, times, marker='o', color='b',
             linestyle='-', linewidth=2, markersize=8)
    plt.xlabel("Size of Random Arrays")
    plt.ylabel("Time taken to sort (seconds)")
    plt.title("Merge Sort Time Complexity Analysis")
    plt.grid(True)
    plt.show()
