-- Create the Wedding database
CREATE DATABASE IF NOT EXISTS Wedding;

-- Switch to the Wedding database
USE Wedding;

-- Create the Guest table to store information about wedding guests
CREATE TABLE IF NOT EXISTS Guest (
    GuestID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    ContactInfo VARCHAR(100) NOT NULL,
    RSVPStatus ENUM('Pending', 'Confirmed', 'Declined') DEFAULT 'Pending',
    DietaryRestrictions VARCHAR(255),
    UNIQUE (Name)
);

-- Insert sample data into the Guest table
INSERT INTO Guest (Name, ContactInfo, RSVPStatus, DietaryRestrictions) 
VALUES 
('John Doe', 'john@example.com', 'Confirmed', 'None'), 
('Jane Smith', 'jane@example.com', 'Pending', 'Vegetarian');

-- Create the Vendor table to store information about wedding vendors
CREATE TABLE IF NOT EXISTS Vendor (
    VendorID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    ContactInfo VARCHAR(100) NOT NULL,
    ServiceProvided VARCHAR(100) NOT NULL,
    UNIQUE (Name)
);

-- Insert sample data into the Vendor table
INSERT INTO Vendor (Name, ContactInfo, ServiceProvided) 
VALUES 
('Floral Design Co.', 'flowers@example.com', 'Flower arrangements'), 
('Catering Services Inc.', 'catering@example.com', 'Catering');

-- Create the SeatingChart table to manage seating arrangements for guests
CREATE TABLE IF NOT EXISTS SeatingChart (
    GuestID INT,
    TableNumber INT,
    SeatNumber INT,
    FOREIGN KEY (GuestID) REFERENCES Guest(GuestID),
    PRIMARY KEY (GuestID)
);

-- Insert sample data into the SeatingChart table
INSERT INTO SeatingChart (GuestID, TableNumber, SeatNumber) 
VALUES 
(1, 1, 1), 
(2, 2, 2);

-- Create the Event table
CREATE TABLE IF NOT EXISTS Event (
  EventID INT PRIMARY KEY AUTO_INCREMENT,
  Date DATE NOT NULL,
  Time TIME NOT NULL,
  Venue VARCHAR(100) NOT NULL,
  Theme VARCHAR(100)
);

-- Insert sample data into the Event table
INSERT INTO Event (Date, Time, Venue, Theme) 
VALUES 
('2024-05-01', '18:00', 'Grand Ballroom', 'Spring Wedding');

-- Create the Budget table
CREATE TABLE IF NOT EXISTS Budget (
  BudgetID INT PRIMARY KEY AUTO_INCREMENT,
  EventID INT NOT NULL,
  Category VARCHAR(100) NOT NULL,
  Amount DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (EventID) REFERENCES Event(EventID)
);

-- Insert sample data into the Budget table
INSERT INTO Budget (EventID, Category, Amount) 
VALUES 
(1, 'Flowers', 500.00), 
(1, 'Catering', 2000.00);

-- Create the RSVP table
CREATE TABLE IF NOT EXISTS RSVP (
  EventID INT NOT NULL,
  GuestID INT NOT NULL,
  Status ENUM('Not Attending', 'Attending') DEFAULT 'Not Attending',
  MealPreference VARCHAR(100),
  AttendanceStatus VARCHAR(100),
  FOREIGN KEY (EventID) REFERENCES Event(EventID),
  FOREIGN KEY (GuestID) REFERENCES Guest(GuestID),
  PRIMARY KEY (EventID, GuestID)
);

-- Insert sample data into the RSVP table
INSERT INTO RSVP (EventID, GuestID, Status, MealPreference, AttendanceStatus) 
VALUES 
(1, 1, 'Confirmed', 'Vegetarian', 'Attending'), 
(1, 2, 'Pending', NULL, NULL);

-- Create the ToDoList table
CREATE TABLE IF NOT EXISTS ToDoList (
  ToDoID INT PRIMARY KEY AUTO_INCREMENT,
  EventID INT NOT NULL,
  Task VARCHAR(255) NOT NULL,
  Completed BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (EventID) REFERENCES Event(EventID)
);

-- Insert sample data into the ToDoList table
INSERT INTO ToDoList (EventID, Task, Completed) 
VALUES 
(1, 'Finalize seating chart', FALSE), 
(1, 'Confirm final guest count', FALSE);

-- Add indexes for efficient searching
ALTER TABLE Guest ADD INDEX (RSVPStatus);                                                                                                                    
ALTER TABLE Guest ADD INDEX (Name);
ALTER TABLE Event ADD INDEX (Date);

