import mysql.connector

# Database connection parameters
DB_HOST = "127.0.0.1"
DB_USER = "root"
DB_PASSWORD = "Cp10101992!"
DB_NAME = "Wedding"
 
# Function to establish a database connection
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        print("Connected to the database")
        return connection
    except mysql.connector.Error as error:
        print("Error connecting to the database:", error)
        return None

# Presentation Layer
def main():
    while True:
        # Display menu options to the user
        display_menu()

        # Let the user select a workflow
        choice = get_user_choice()

        # Execute the selected workflow
        if choice == 1:
            workflow1()
        elif choice == 2:
            workflow2()
        elif choice == 3:
            workflow3()
        elif choice == 4:
            break
        else:
            print("Invalid choice. Please select a valid option.")

# Display menu options
def display_menu():
    print("Wedding Planner Menu")
    print("1. View Guest List")
    print("2. View Vendor Details")
    print("3. Update RSVP Status")
    print("4. Exit")

# Get user choice
def get_user_choice():
    while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice in range(1, 5):
                return choice
            else:
                print("Invalid choice. Please enter a number between 1 and 4.")
        except ValueError:
            print("Invalid input. Please enter a number.")

# Business Logic Layer
def workflow1():
    # Establish database connection
    connection = connect_to_database()
    if connection:
        try:
            # Fetch guest list
            cursor = connection.cursor()
            query = "SELECT GuestID, Name, ContactInfo FROM Guest"
            cursor.execute(query)
            for (guest_id, name, contact_info) in cursor:
                print(f"GuestID: {guest_id}, Name: {name}, ContactInfo: {contact_info}")
        except mysql.connector.Error as error:
            print("Error fetching guest list:", error)
        finally:
            # Close cursor and database connection
            cursor.close()
            connection.close()

def workflow2():
    # Establish database connection
    connection = connect_to_database()
    if connection:
        try:
            # Fetch vendor details
            cursor = connection.cursor()
            query = "SELECT VendorID, Name, ContactInfo, ServiceProvided FROM Vendor"
            cursor.execute(query)
            for (vendor_id, name, contact_info, service_provided) in cursor:
                print(f"VendorID: {vendor_id}, Name: {name}, ContactInfo: {contact_info}, ServiceProvided: {service_provided}")
        except mysql.connector.Error as error:
            print("Error fetching vendor details:", error)
        finally:
            # Close cursor and database connection
            cursor.close()
            connection.close()

def workflow3():
    # Establish database connection
    connection = connect_to_database()
    if connection:
        try:
            # Update RSVP status
            guest_id = int(input("Enter Guest ID: "))
            rsvp_status = input("Enter new RSVP Status (Pending/Confirmed/Declined): ")

            cursor = connection.cursor()
            update_query = "UPDATE Guest SET RSVPStatus = %s WHERE GuestID = %s"
            cursor.execute(update_query, (rsvp_status, guest_id))
            connection.commit()
            print("RSVP status updated successfully.")
        except mysql.connector.Error as error:
            print("Error updating RSVP status:", error)
            connection.rollback()
        finally:
            # Close cursor and database connection
            cursor.close()
            connection.close()

# Execute the main function
if __name__ == "__main__":
    main()
